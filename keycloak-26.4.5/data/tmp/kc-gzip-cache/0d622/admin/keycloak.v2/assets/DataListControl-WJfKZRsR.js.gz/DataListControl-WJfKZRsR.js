import{aw as e,av as o}from"./main-CEQTdNHa.js";import*as m from"react";import{s as i}from"./DataListItemRow-BYgIImJ0.js";const l=s=>{var{children:a,className:t=""}=s,r=e(s,["children","className"]);return m.createElement("div",Object.assign({className:o(i.dataListItemControl,t)},r),a)};l.displayName="DataListControl";export{l as D};
//# sourceMappingURL=DataListControl-WJfKZRsR.js.map
